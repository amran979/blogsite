<?php
define("DB_HOST", "localhost");
define("DB_USER", "epiz_21381869");
define("DB_PASS", "ss728292");
define("DB_NAME", "epiz_21381869_blog");
define("TITLE", "Healthy life");
define("KEYWORDS", "Honer Your Health");


